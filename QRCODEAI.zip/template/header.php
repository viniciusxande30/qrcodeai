<div class="bg-primary position-relative">
  <div class="overlay-gradient"></div>
  <div class="container position-relative">
  	<div class="row py-5">
    	<div class="col">
        <h1 class="display-1">Gerador de QR Code</h1>
        <p>Gere um QR Code Gratuito para o seu negócio<br></p>
        <p><a href="https://rsweb.com.br" class="btn btn-primary btn-lg shadow" role="button">Entre em Contato Conosco &raquo;</a></p>
    </div>
    </div>
  </div>
</div>