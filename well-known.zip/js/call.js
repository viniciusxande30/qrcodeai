/* call QRcdr plugin */
$(document).ready(function(){
    QRcdr = $('.qrcdr').qrcdr({
        svglogo : false
    });
});
